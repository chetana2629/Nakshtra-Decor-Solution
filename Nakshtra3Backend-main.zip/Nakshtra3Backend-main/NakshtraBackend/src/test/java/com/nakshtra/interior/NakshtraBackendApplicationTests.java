package com.nakshtra.interior;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NakshtraBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
