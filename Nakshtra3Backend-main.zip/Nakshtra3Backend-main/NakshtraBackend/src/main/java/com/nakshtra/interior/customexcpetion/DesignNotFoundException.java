package com.nakshtra.interior.customexcpetion;

public class DesignNotFoundException extends RuntimeException {

	public DesignNotFoundException(String msg) {
		super(msg);
	}

	
}
