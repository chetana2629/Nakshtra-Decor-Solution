package com.nakshtra.interior.entity;

public enum ProjectStatus {
	IN_PROGRESS,
    COMPLETED,
    ON_HOLD,
    CANCELLED
}
