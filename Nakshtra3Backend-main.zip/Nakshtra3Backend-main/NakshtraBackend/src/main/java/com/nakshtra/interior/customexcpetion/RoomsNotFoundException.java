package com.nakshtra.interior.customexcpetion;

public class RoomsNotFoundException extends Exception {

	public RoomsNotFoundException(String msg) {
		super(msg);
	}
}
