package com.nakshtra.interior.customexcpetion;

public class FurnitureNotFoundException extends RuntimeException{

	public FurnitureNotFoundException(String msg) {
		super(msg);
	}

	
}
