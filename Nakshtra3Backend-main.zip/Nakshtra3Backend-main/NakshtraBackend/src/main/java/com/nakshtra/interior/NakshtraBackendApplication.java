package com.nakshtra.interior;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.nakshtra.interior")
public class NakshtraBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(NakshtraBackendApplication.class, args);
    }
}
